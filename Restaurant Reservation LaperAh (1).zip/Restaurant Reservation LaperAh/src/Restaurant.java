
public class Restaurant {

}
