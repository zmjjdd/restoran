
public class MenuItem {

}
